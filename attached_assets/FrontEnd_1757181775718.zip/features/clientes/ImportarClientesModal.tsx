// This component is no longer used and can be deleted.
// The functionality has been replaced by the new RNC database management system in `useDGIIDataStore`.
import React from 'react';

const ImportarClientesModal: React.FC = () => null;

export default ImportarClientesModal;