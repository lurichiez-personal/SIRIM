// This component is deprecated and has been replaced by features/nomina/HistorialNominaPage.tsx
// It can be safely removed in the future.
import React from 'react';

const HistorialNominaModal: React.FC = () => null;

export default HistorialNominaModal;
